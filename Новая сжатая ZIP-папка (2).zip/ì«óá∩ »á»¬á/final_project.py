import pygame
import sys
import os
import moviepy.editor

#возможность выхода из заставки
def terminate():
    pygame.quit()
    sys.exit()

#загрузка заставки игры
def start_screen():
    intro_text = [""]

    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    flag = True
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('yellow'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while flag:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return  # начинаем игру
        pygame.display.flip()
        clock.tick(FPS)

#создание меню
class Menu:
    def __init__(self):
        self.callback = []
        self.option_surfaces = []
        self.current_option = 0
    #добавление различных функций в меню
    def append_option(self, option, callback):
        self.option_surfaces.append(ARIAL_50.render(option, True, (255, 255, 255)))
        self.callback.append(callback)
    #возможность переключать функции
    def switch(self, direction):
        self.current_option = max(0, min(self.current_option + direction,
                                         len(self.option_surfaces) - 1))
        return self.current_option
    #возможность выбора функций
    def select(self):
        self.callback[self.current_option]()

    #отображение
    def draw(self, surf, x, y, option_y_padding):
        for i, option in enumerate(self.option_surfaces):
            option_rect = option.get_rect()
            option_rect.topleft = (x, y + i * option_y_padding)
            if i == self.current_option:
                pygame.draw.rect(surf, (0, 255, 0), option_rect)
            surf.blit(option, option_rect)


#загрузка фото(для заставки)
def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as message:
        print("Cannot load image", name)
        raise SystemExit(message)

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
            image.set_colorkey(color_key)
        else:
            image = image.convert_alpha()
    return image

#необходимые данные для игры
class Ship(pygame.sprite.Sprite):
    def __init__(self, image_file, location):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = location

#создание игры
class Area():
    def __init__(self, x_area=0, y_area=0, width=10, height=10, color=None):
        self.rect = pygame.Rect(x_area, y_area, width, height)
        self.fill_color = back
        if color:
            self.fill_color = color

    def color(self, new_color):
        self.fill_color = new_color

    def fill(self):
        pygame.draw.rect(window, self.fill_color, self.rect)

    def collidepoint(self, x_area, y_area):
        return self.rect.collidepoint(x_area, y_area)

    def colliderect(self, rect):
        return self.rect.colliderect(rect)

#создание платформы
class Label(Area):
    def set_text(self, text, fsize=12, text_color=(0, 0, 0)):
        self.image = pygame.font.SysFont('verdana', fsize).render(text, True, text_color)

    def draw(self, shift_x=0, shift_y=0):
        self.fill()
        window.blit(self.image, (self.rect.x + shift_x, self.rect.y + shift_y))
        window1.blit(self.image, (self.rect.x + shift_x, self.rect.y + shift_y))

#отображение игры
class Picture(Area):
    def __init__(self, filename, x_game=0, y_game=0, width=10, height=10):
        Area.__init__(self, x_area=x_game, y_area=y_game, width=width, height=height, color=None)
        self.image = pygame.image.load(filename)

    def draw(self):
        window.blit(self.image, (self.rect.x, self.rect.y))

#данные для работы
pygame.init()
size = WIDTH, HEIGHT = 500, 500
clock = pygame.time.Clock()
ARIAL_50 = pygame.font.SysFont('arial', 50)
all_sprites = pygame.sprite.Group()
back = (200, 255, 255)
window = pygame.display.set_mode((600, 500))
window.fill(back)
window1 = pygame.display.set_mode((600, 500))
window1.fill(back)
clock = pygame.time.Clock()
dir_x = 3
dir_y = 3
screen = pygame.display.set_mode(size)
platform_x = 200
platform_y = 330
move_right = False
move_left = False
game_over = False

FPS = 50
score = 0
font = pygame.font.Font(None, 30)
video = moviepy.editor.VideoFileClip("video.mp4")
bad_video = moviepy.editor.VideoFileClip("videoplayback.mp4")
intro_video = moviepy.editor.VideoFileClip("intro.mp4")
clock = pygame.time.Clock()
file = 'some.mp3'
menu_music = 'menu_music.mp3'
ship = Ship("ship.jpg", [0, 0])
menu = Menu()
#добавления функций в меню
menu.append_option('Начать', lambda: print())
menu.append_option('Интро', lambda: intro_video.preview())
menu.append_option('Выйти', quit)
ball = Picture('ball.png', 160, 200, 50, 50)
platform = Picture('platform.png', platform_x, platform_y, 100, 30)
start_x = 5
start_y = 5
count = 9
pygame.display.set_caption("TheNeverHood")
start_screen()
monsters = []
running = True
new_lvl = False
#cоздание врагов
for j in range(3):
    y_game = start_y + (55 * j)
    x_game = start_x + (27.5 * j)
    for i in range(count):
        enemy = Picture('enemy.png', x_game, y_game, 50, 50)
        monsters.append(enemy)
        x_game = x_game + 55
    count = count - 1
#музыка для меню
pygame.mixer.init()
pygame.mixer.music.load(menu_music)
pygame.mixer.music.play(-1)
#запуск игры
while running:
    #загрузка меню
    for eventi in pygame.event.get():
        if eventi.type == pygame.QUIT:
            running = False #выйти из меню
        if eventi.type == pygame.KEYDOWN:
            if eventi.key == pygame.K_w or eventi.key == pygame.K_UP:
                menu.switch(-1) #переключение функций в меню
            elif eventi.key == pygame.K_s or eventi.key == pygame.K_DOWN:
                menu.switch(1) #переключение функций в меню
            elif eventi.key == pygame.K_RETURN:
                menu.select() #выбор функции
                #музыка для игры
                pygame.mixer.init()
                pygame.mixer.music.load(file)
                pygame.mixer.music.play(-1)
                #запуск игры
                while not game_over:
                    pygame.display.set_mode((500, 500))
                    ball.fill()
                    platform.fill()
                    screen.blit(ship.image, ship.rect)
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            game_over = True
                            running = False
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_RIGHT:
                                move_right = True
                            if event.key == pygame.K_LEFT:
                                move_left = True
                        elif event.type == pygame.KEYUP:
                            if event.key == pygame.K_RIGHT:
                                move_right = False
                            if event.key == pygame.K_LEFT:
                                move_left = False
                    if move_right:
                        platform.rect.x += 3 #передвижение панели
                    if move_left:
                        platform.rect.x -= 3 #передвижение панели
                    ball.rect.x += dir_x
                    ball.rect.y += dir_y
                    if ball.rect.y < 0:
                        dir_y *= -1
                    if ball.rect.x > 450 or ball.rect.x < 0:
                        dir_x *= -1
                    if ball.rect.y > 350:
                        #поражение
                        time_text = Label(150, 150, 50, 50, back)
                        time_text.set_text('YOU LOSE', 60, (255, 0, 0))
                        time_text.draw(10, 10)
                        bad_video.preview()
                        game_over = True
                        running = False
                        pygame.quit()
                    if len(monsters) == 0:
                        #победа
                        time_text = Label(150, 150, 50, 50, back)
                        time_text.set_text('YOU WIN', 60, (0, 200, 0))
                        time_text.draw(10, 10)
                        video.preview()
                        game_over = True
                        new_lvl = True
                        running = False
                        pygame.quit()
                    if ball.rect.colliderect(platform.rect):
                        dir_y *= -1
                    for mon in monsters:
                        mon.draw()
                        if mon.rect.colliderect(ball.rect):
                            monsters.remove(mon) #ударение врагов
                            mon.fill()
                            dir_y *= -1
                            score += 1 #счёт очков
                    text = font.render("Очки: ", True, (255, 100, 10))
                    text2 = font.render(str(score), True, (255, 100, 10))
                    window.blit(text, [20, 420])
                    window.blit(text2, [90, 420])
                    platform.draw()
                    ball.draw()
                    pygame.display.update()
                    clock.tick(40)
    screen.fill((0, 0, 0))
    menu.draw(screen, 100, 100, 75)
    pygame.display.flip()
quit() #выход из игры